package edu.cqu.result.annotations;

/**
 * Created by dyc on 2017/5/31.
 */
public @interface CycleOffset {
}
