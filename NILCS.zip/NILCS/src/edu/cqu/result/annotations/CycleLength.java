package edu.cqu.result.annotations;

/**
 * Created by dyc on 2017/5/29.
 */
public @interface CycleLength {

}
