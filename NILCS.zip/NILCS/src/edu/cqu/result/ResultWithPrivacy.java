package edu.cqu.result;

import edu.cqu.result.annotations.AverageField;

public class ResultWithPrivacy extends ResultCycle {
    @AverageField
    protected int totalEntropy;
    @AverageField
    protected int leakedEntropy;
    @AverageField
    protected int ub;

    @AverageField
    protected int maxLen;

    @AverageField
    protected int maxInduceWidth;
    @AverageField
    protected long messageSizeCount;
    @AverageField
    protected long messageSizeCount_PreInference;
    @AverageField
    protected long messageSizeCount_ItrInference;
    @AverageField
    protected int ncccs_PreInference;
    @AverageField
    protected int ncccs_ItrInference;
    @AverageField
    protected int messageCount_Inference;


    public int getMaxLen() {
        return maxLen;
    }

    public void setMaxLen(int maxLen) {
        this.maxLen = maxLen;
    }

    public long getMessageSizeCount_PreInference() {
        return messageSizeCount_PreInference;
    }

    public void setMessageSizeCount_PreInference(long messageSizeCount_PreInference) {
        this.messageSizeCount_PreInference = messageSizeCount_PreInference;
    }

    public long getMessageSizeCount_ItrInference() {
        return messageSizeCount_ItrInference;
    }

    public void setMessageSizeCount_ItrInference(long messageSizeCount_ItrInference) {
        this.messageSizeCount_ItrInference = messageSizeCount_ItrInference;
    }

    public int getNcccs_PreInference() {
        return ncccs_PreInference;
    }

    public void setNcccs_PreInference(int ncccs_PreInference) {
        this.ncccs_PreInference = ncccs_PreInference;
    }

    public int getNcccs_ItrInference() {
        return ncccs_ItrInference;
    }

    public void setNcccs_ItrInference(int ncccs_ItrInference) {
        this.ncccs_ItrInference = ncccs_ItrInference;
    }

    public void setMessageCount_Inference(int messageCount_Inference) {
        this.messageCount_Inference = messageCount_Inference;
    }

    public int getMessageCount_Inference() {
        return messageCount_Inference;
    }


    public int getMaxInduceWidth() {
        return maxInduceWidth;
    }

    public void setMaxInduceWidth(int maxInduceWidth) {
        this.maxInduceWidth = maxInduceWidth;
    }

    public long getMessageSizeCount() {
        return messageSizeCount;
    }

    public void setMessageSizeCount(long messageSizeCount) {
        this.messageSizeCount = messageSizeCount;
    }

    public int getUb() {
        return ub;
    }

    public void setUb(int ub) {
        this.ub = ub;
    }

    public void setTotalEntropy(int totalEntropy) {
        this.totalEntropy = totalEntropy;
    }


    public double getLossRate(){
        return leakedEntropy * 1.0 / totalEntropy;
    }

    public void setLeakedEntropy(int leakedEntropy) {
        this.leakedEntropy = leakedEntropy;
    }
}
