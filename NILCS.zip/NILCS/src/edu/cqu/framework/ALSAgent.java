package edu.cqu.framework;

import edu.cqu.core.Message;
import edu.cqu.core.SyncMailer;
import edu.cqu.ordering.BFSSyncAgent;

import java.util.HashMap;
import java.util.Map;

public abstract class ALSAgent extends BFSSyncAgent {

    private static final int MSG_HEIGHT = 0xFFAFA;
    private static final int MSG_INFORM_HEIGHT = 0xFFAFB;
    private static final int MSG_COST = 0xFFAFC;
    private static final int MSG_BEST_STEP = 0xFFAFD;

    private int h;
    private int bestCost;
    private int bestStep;
    private int[] best;
    private int step;
    private int[][] localCost;
    private Map<Integer, int[]> value;
    private Map<Integer,int[]> localView;

    private int heightReceived;
    private int counter;

    private int m;
    private boolean alsStarted;

    private int iteration;

    private boolean isSent;

    private int[] sumOfCost=null;
    private int c_v = Integer.MAX_VALUE;

    public ALSAgent(int id, int[] domain, int[] neighbours, Map<Integer, int[][]> constraintCosts, Map<Integer, int[]> neighbourDomains, SyncMailer mailer,int m) {
        super(id, domain, neighbours, constraintCosts, neighbourDomains, mailer);
        counter = Integer.MAX_VALUE;
        localView = new HashMap<>();
        this.m = m;
    }

    @Override
    protected void pseudoTreeCreated() {
        if (children.size() == 0){
            h = 0;
            sendMessage(new Message(id,parent,MSG_HEIGHT,h));
        }
        else if (heightReceived == children.size() && !isSent){
            isSent = true;
            if (id != 1) {
                sendMessage(new Message(id, parent, MSG_HEIGHT, ++h));
            }
            else {
                h++;
                counter = h;
                for (int child : children){
                    sendMessage(new Message(id,child,MSG_INFORM_HEIGHT,h));
                }
            }
        }
    }

    @Override
    public void disposeMessage(Message message) {
        super.disposeMessage(message);
        switch (message.getType()){
            case MSG_HEIGHT:
                int childHeight = (int) message.getValue();
                if (childHeight > h){
                    h = childHeight;
                }
                if (++heightReceived == children.size() && !isSent){
                    isSent = true;
                    if (id != 1) {
                        sendMessage(new Message(id, parent, MSG_HEIGHT, ++h));
                    }
                    else {
                        h++;
                        counter = h;
                        for (int child : children){
                            sendMessage(new Message(id,child,MSG_INFORM_HEIGHT,h));
                        }
                    }
                }
                break;
            case MSG_INFORM_HEIGHT:
                counter = h = (int) message.getValue() - 1;
                for (int child : children){
                    sendMessage(new Message(id,child,MSG_INFORM_HEIGHT,h));
                }
                break;
            case MSG_BEST_STEP:
                int receivedStep = (int) message.getValue();
                best = value.get(receivedStep % (level * 2 + h));
                bestStep = receivedStep;
                break;
            case MSG_COST:
                int[] t = (int[]) message.getValue();
                if (sumOfCost==null){
                    sumOfCost=new int[t.length];
                }
                for (int i = 0; i < t.length; i++)
                    sumOfCost[i] += t[i];
                break;
        }
    }
    private int testStep;

    @Override
    public void allMessageDisposed() {
        super.allMessageDisposed();

        if (counter != Integer.MAX_VALUE){
            if (--counter < 0){
                counter = Integer.MAX_VALUE;
                h++;
                value = new HashMap<>();
                for (int neighbourId : neighbours){
                    localView.put(neighbourId,new int[2 * (level + h)]);
                }
                localCost = new int[h][num];
                if (id == 1){
                    bestCost = Integer.MAX_VALUE;
                }
                bestStep = 0;
                step = 0;
                alsReady();
                alsStarted = true;
            }
        }
        if (alsStarted){
            if (step < (m + h + level)){
                decision();
                localCost[step % h] = getLocalCost();
                int[] cost = calculateStepCost();
                if(sumOfCost==null){
                    sumOfCost=new int[cost.length];
                }
                for (int i=0;i<cost.length;i++)
                    cost[i] += sumOfCost[i];
                if (step > 10)
                    for(int i:cost)
                        c_v =Math.min(c_v,i);
                if (id != 1) {
                    sendMessage(new Message(id, parent, MSG_COST, cost));
                }
                for (int child : children){
                    sendMessage(new Message(id,child,MSG_BEST_STEP,bestStep));
                }
                if (id == 1){
                    if (c_v < bestCost && step >= h){
                        bestCost = c_v;
                        c_v = Integer.MAX_VALUE - 1;
                        best = value.get(step % (level * 2 + h));
                        bestStep = step;
                    }

                }
                for (int i=0;i<sumOfCost.length;i++)
                    sumOfCost[i] = 0;
                step++;
            }
            else if (iteration++ < (level + h)) {
                for (int child : children){
                    sendMessage(new Message(id,child,MSG_BEST_STEP,bestStep));
                }
            }
            else {
                stopProcess();
            }
        }
        testStep++;
    }

    protected abstract void alsReady();
    protected abstract void decision();

    protected void assignAlsValue(int[] indexes){
        this.value.put(step % (level * 2 + h), indexes);
    }

    private int[] calculateStepCost(){
        int step;
        if (this.step >= h - 1)
            step = (this.step - h + 1) % h;
        else
            return new int[num];
        return localCost[step];
    }


    public double getBestCost(){
        return bestCost / 2;
    }


}
