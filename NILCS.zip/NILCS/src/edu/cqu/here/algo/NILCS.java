package edu.cqu.here.algo;

import edu.cqu.core.Message;
import edu.cqu.core.SyncMailer;
import edu.cqu.framework.ALSAgent;
import edu.cqu.result.ResultAls;

import java.util.*;

//基于局部代价模拟的算法LCS
public class NILCS extends ALSAgent {

    private final static int TYPE_VALUE_MESSAGE = 888;//消息类型
    private final static int CYCLE_COUNT_END = 666;//结束最大轮次

    private final static double alpha =11;//选定概率
    //private final static int randCycle = 1000;
    private final static int randCycle = 60;//
    private final static int exchangeCycle = 50;//交换间隔
    //private final static int exchangeCycle = 1000;
    private final static int C = 4;//种群的数量
    private final static int P = 24;//个体数量
    private final static double [] beta = {0.6, 0.7, 0.8, 0.9};//种群的衰变率
    private final static double gamma = 0.7;//学习率
    private final static double  r = 0.00001;//
    private int currentCycle = 1;//当前轮次

    private int[] self_ind;//
    private Map<Integer, int[]> neighbour_index;
    private double[][] est;//局部代价
    private double[][] tp;//选值的概率
    private double[][] estR;//
    private double[][] prblt;//

    public NILCS(int id, int[] domain, int[] neighbours, Map<Integer, int[][]> constraintCosts, Map<Integer, int[]> neighbourDomains, SyncMailer mailer) {
        super(id, domain, neighbours, constraintCosts, neighbourDomains, mailer,CYCLE_COUNT_END);
        int K = C * P;//所有个体
        num = K;
        self_ind = new int[K];//所有个体数组
        neighbour_index = new HashMap<>();
        initLce();
        tp = new double[C][domain.length];
        estR = new double[C][domain.length];
        prblt = new double[C][domain.length];
    }

    //初始化（假设所有处于最坏情况，与邻居构成最大局部代价）
    private void initLce(){
        est = new double[C][domain.length];
        for (int i = 0; i < domain.length; i++){
            double sum = 0;
            for (int neighbour : neighbours){
                int max = -1;
                int len = neighbourDomains.get(neighbour).length;
                    for (int j = 0; j < len; j++) {
                        int cost = constraintCosts.get(neighbour)[i][j];
                        if (cost > max) {
                            max = cost;
                        }

                    sum += max;//计算节点与所有邻居最大代价
                }

            }
            for (int j = 0; j < C; j++)
                est[j][i] = sum;//将邻居节点的局部代价初始化
        }
    }

    @Override
    protected void alsReady() {
        int kvId = 0;
        //种群个体随机选值
        for (int i = 0; i < C; ++i){
            for (int j = 0; j < P; j++){
                self_ind[kvId] = (int)(Math.random() * domain.length);
                kvId++;
            }
        }
        assignValueIndex (self_ind);
        assignAlsValue(self_ind);//
        for (int neighborId : neighbours) {
            sendMessage(new Message(id, neighborId, TYPE_VALUE_MESSAGE, self_ind));
        }
    }

    @Override
    protected void decision() {
        lcsWork();
    }

    private void lcsWork() {
        //在接收到邻居的赋值后，计算局部约束代价
        for (int i = 0; i < C; i++) {
            for (int j = 0; j < P; j++) {
                int k = i * P + j;//定位个体的索引
                int sum = 0;
                int this_value = self_ind[k];
                for (Map.Entry<Integer, int[]> entry : neighbour_index.entrySet()) {
                    int neighbour_id = entry.getKey();
                    int neighbour_value = entry.getValue()[k];

                    sum += constraintCosts.get(neighbour_id)[this_value][neighbour_value];
                }
                //使用指数加权移动对局部代价进行模拟，sum * (1 - beta[i])为初始轮次的局部代价
                est[i][this_value] = est[i][this_value] * beta[i] + sum * (1 - beta[i]);
            }
        }
        //设置交换轮，交换代价
        if (currentCycle % exchangeCycle == 0) {
            for (int j = 0; j < domain.length; j++) {
                double min = Integer.MAX_VALUE - 1;
                //寻找最优种群
                for (int i = 0; i < C; i++) {
                    min = Math.min(est[i][j], min);
                }
                for (int i = 0; i < C; i++) {
                    est[i][j] = est[i][j] * (1 - gamma) + min * gamma;//向最优种群移动
                }
            }
        }
        select();//执行新一轮的选值
        assignValueIndex(self_ind);
        //执行邻居忽略策略
        if(currentCycle>1){
        Ignoreneighbors();}
//        RandomMore();
        currentCycle++;
    }


    //在更新与交换后，执行新一轮的选值。依据概率选择
    private void select(){
        int kcId = 0;
        for (int c = 0; c < C; c++){
            for (int d = 0; d < est[c].length; d++){
                estR[c][d] = 1 / (est[c][d] + r * est[c][d] * est[c][d]);//计算分子
            }
            double sum = 0.0;
            //double sum1 = 0.0;
            for (int d = 0; d < domain.length; d++) {
                sum += Math.pow(estR[c][d], alpha);//计算概率公式的分母
            }
            for (int d = 0; d < domain.length; d++){
                tp[c][d] =  Math.pow(estR[c][d],alpha) / sum;//选择概率
            }
            double acc = 0.0;
            for (int d = 0; d < domain.length; d++){
                acc += tp[c][d];//
                prblt[c][d] = acc;//
            }
            for (int i = 0; i < P; i++){
                self_ind[kcId] = selectValue(c);
                kcId++;
            }
        }
    }

    private int selectValue(int c){
        if (currentCycle % randCycle == 0 || currentCycle < 10){
            return (int)(Math.random() * domain.length);
        }
        double rand_value = Math.random();
        for (int i = 0; i < prblt[c].length; i++){
            if (rand_value < prblt[c][i]){
                return i;
            }
        }
        return (int)(Math.random() * domain.length);
    }


    private void Ignoreneighbors() {
        int agent1 = -1;
        //随机忽略邻居(RandomlyIgnoring)
        agent1 = neighbours[(int) (neighbours.length * Math.random())];
        for (int c = 0; c < C; c++) {
            //忽略最大和最小的邻居代价(ExtremelyIgnoring)，
            int maxIndex = -1;
            int minIndex = -1;
            int maxCost = Integer.MIN_VALUE;
            int minCost = Integer.MAX_VALUE;
            for (int i = 0; i < C; i++) {
                for (int j = 0; j < P; j++) {
                    int k = i * P + j;//定位个体的索引
                    int this_value = self_ind[k];
                    for (Map.Entry<Integer, int[]> entry : neighbour_index.entrySet()) {
                        int neighbour_id = entry.getKey();
                        int neighbour_value = entry.getValue()[k];
                        int cost = constraintCosts.get(neighbour_id)[this_value][neighbour_value];
                        if (cost > maxCost) {
                            maxCost = cost;
                            maxIndex = neighbour_id;
                        }
                        if (cost < minCost) {
                            minCost = cost;
                            minIndex = neighbour_id;
                        }
                    }
                }
            }

            for (int neighbourId : neighbours) {
                //随机忽略邻居(RandomlyIgnoring)
//                if ( neighbourId !=  agent1){
                    // 忽略最大和最小的邻居代价(ExtremelyIgnoring)
                 if ( neighbourId !=  minIndex && neighbourId !=  maxIndex){
                    //混合策略（MixedIgnoring）
//            if ( neighbourId !=  agent1 || neighbourId !=  minIndex || neighbourId !=  maxIndex){

                    sendMessage(new Message(id, neighbourId, TYPE_VALUE_MESSAGE, self_ind));
                }
            }
        }
    }

    private  void RandomMore(){
        List<int[]> group = new ArrayList<>();
        group.add(new int[]{0,0});
        group.add(new int[]{0,1});
        group.add(new int[]{1,0});
        group.add(new int[]{1,1});
        for (int neighbourId : neighbours) {
            Random random = new Random();
            int index = random.nextInt(group.size());
            int[] label=group.get(index);
            if(label[0] == label[1]){
                sendMessage(new Message(id, neighbourId, TYPE_VALUE_MESSAGE, self_ind));
            }
        }
    }

    @Override
    public void disposeMessage(Message msg) {
        super.disposeMessage(msg);
        switch (msg.getType()){
            case TYPE_VALUE_MESSAGE:
                disposeValueMessage((int[]) msg.getValue(),msg.getIdSender());
                break;
        }
    }

    private void disposeValueMessage(int[] receivedInd, int sender) {
        neighbour_index.put(sender,receivedInd);
        updateLocalView(sender,receivedInd);
    }

    @Override
    public void runFinished() {
        ResultAls resultCycle = new ResultAls();
        resultCycle.setAgentValues(id,1);
        mailer.setResultCycle(id,resultCycle);
    }
}