package edu.cqu.here.main;

import edu.cqu.core.FinishedListener;
import edu.cqu.core.ProgressChangedListener;
import edu.cqu.core.Solver;
import edu.cqu.result.Result;
import edu.cqu.result.ResultAls;
import edu.cqu.utils.FileUtils;

public class NILCS_batch_main {
    public static void main(String[] args) {
        Solver solver = new Solver();

        String adp = "D:\\paper\\paper1\\NILCS\\src\\edu\\cqu\\here\\agentDescriptorPath\\NILCS.xml";
        String algo = "NILCS";
        String pr = "D:\\problem\\SFN\\SFN_150_20_10";
        int vt =10;
        String outDir = "D:\\paper\\paper1\\result\\ExtremelyIgnoring";
        boolean write = true;

        solver.batchSolve(adp, algo, pr,vt, new FinishedListener() {
            @Override
            public void onFinished(Result result) {
                ResultAls resultCycle=(ResultAls) result;
                double[] b = resultCycle.bestCostInCycle;
                FileUtils.writeStringToFile( "\n",outDir + "\\" + algo +".txt");
                for (int i = 0; i < b.length; i++) {
                    System.out.println("cycle " + (i + 1) + " : " + b[i]);
                    FileUtils.writeStringToFile( String.valueOf(b[i]) + " ",outDir + "\\" + algo +".txt");
                }

            }
        },new ProgressChangedListener(){
            @Override
            public void onProgressChanged(double percentage, Result result) {

                ResultAls resultCycle=(ResultAls) result;
                double[] b = resultCycle.bestCostInCycle;
                if (write){
                    FileUtils.writeStringToFile( "\n",outDir + "\\" + algo +".txt");
                }
                for (int i = 0; i < b.length; i++) {
//                    System.out.println("cycle " + (i + 1) + " : " + b[i]);
                    if (write) {

                        FileUtils.writeStringToFile(String.valueOf(b[i]) + " ", outDir + "\\" + algo + ".txt");
                    }
                }
            }


            @Override
            public void interrupted(String reason) {
                System.out.println(reason);
            }
        });
    }

}

