package edu.cqu.here.main;

import edu.cqu.core.FinishedListener;
import edu.cqu.core.Solver;
import edu.cqu.result.Result;
import edu.cqu.result.ResultAls;
import edu.cqu.utils.FileUtils;

public class NILCS_main {
    public static void main(String[] args) {
        Solver solver=new Solver();

        String agentDescriptorPath = "D:\\paper\\paper1\\NILCS\\src\\edu\\cqu\\here\\agentDescriptorPath\\NILCS.xml";
        String algo = "NILCS";
        String pr="D:\\problem\\Random_dcop\\70_10_0.1\\RANDOM_DCOP_70_10_density_0.1_0.xml";
        solver.solve(agentDescriptorPath, algo, pr, new FinishedListener() {


            @Override

            public void onFinished(Result result) {
                ResultAls resultCycle=(ResultAls) result;
                double[] b = resultCycle.bestCostInCycle;
                for (int i = 0; i < b.length; i++) {
                    System.out.println(b[i]);
                }
            }
        },false,false);
    }

}

