package edu.cqu.core;

/**
 * Created by dyc on 2017/6/16.
 */
public class CommunicationStructure {
}
