package edu.cqu.core;

public interface Stringifier {
    String stringify(Object object);
}
