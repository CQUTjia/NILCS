package edu.cqu.core;

import edu.cqu.result.Result;

/**
 * Created by dyc on 2017/6/20.
 */
public interface FinishedListener {
    void onFinished(Result result);
}
