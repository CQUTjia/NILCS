# DCOPSolverInfrastructure

LCS to run -- **_here_**.  
**_main_** can test single problem  
change the **agentDescriptorPath** and **pr**   
run it  
for different problem, change parameter in **_algo/LCS_**
 

